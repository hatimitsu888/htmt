
package net.mcreator.foods_craft.item;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.common.util.EnumHelper;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.client.event.ModelRegistryEvent;

import net.minecraft.item.ItemArmor;
import net.minecraft.item.Item;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;

import net.mcreator.foods_craft.creativetab.TabFoodscraft;
import net.mcreator.foods_craft.ElementsFoodscraft;

@ElementsFoodscraft.ModElement.Tag
public class ItemBreadarmor extends ElementsFoodscraft.ModElement {
	@GameRegistry.ObjectHolder("foods_craft:breadarmorhelmet")
	public static final Item helmet = null;
	@GameRegistry.ObjectHolder("foods_craft:breadarmorbody")
	public static final Item body = null;
	@GameRegistry.ObjectHolder("foods_craft:breadarmorlegs")
	public static final Item legs = null;
	@GameRegistry.ObjectHolder("foods_craft:breadarmorboots")
	public static final Item boots = null;
	public ItemBreadarmor(ElementsFoodscraft instance) {
		super(instance, 27);
	}

	@Override
	public void initElements() {
		ItemArmor.ArmorMaterial enuma = EnumHelper.addArmorMaterial("BREADARMOR", "foods_craft:bread_armor", 5, new int[]{2, 2, 3, 1}, 6, null, 0f);
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.HEAD).setUnlocalizedName("breadarmorhelmet")
				.setRegistryName("breadarmorhelmet").setCreativeTab(TabFoodscraft.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.CHEST).setUnlocalizedName("breadarmorbody")
				.setRegistryName("breadarmorbody").setCreativeTab(TabFoodscraft.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.LEGS).setUnlocalizedName("breadarmorlegs")
				.setRegistryName("breadarmorlegs").setCreativeTab(TabFoodscraft.tab));
		elements.items.add(() -> new ItemArmor(enuma, 0, EntityEquipmentSlot.FEET).setUnlocalizedName("breadarmorboots")
				.setRegistryName("breadarmorboots").setCreativeTab(TabFoodscraft.tab));
	}

	@SideOnly(Side.CLIENT)
	@Override
	public void registerModels(ModelRegistryEvent event) {
		ModelLoader.setCustomModelResourceLocation(helmet, 0, new ModelResourceLocation("foods_craft:breadarmorhelmet", "inventory"));
		ModelLoader.setCustomModelResourceLocation(body, 0, new ModelResourceLocation("foods_craft:breadarmorbody", "inventory"));
		ModelLoader.setCustomModelResourceLocation(legs, 0, new ModelResourceLocation("foods_craft:breadarmorlegs", "inventory"));
		ModelLoader.setCustomModelResourceLocation(boots, 0, new ModelResourceLocation("foods_craft:breadarmorboots", "inventory"));
	}
}
