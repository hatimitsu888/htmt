
package net.mcreator.foods_craft.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.foods_craft.item.ItemRawHumbug;
import net.mcreator.foods_craft.item.ItemHumbug;
import net.mcreator.foods_craft.ElementsFoodscraft;

@ElementsFoodscraft.ModElement.Tag
public class RecipeHumbugRecipe extends ElementsFoodscraft.ModElement {
	public RecipeHumbugRecipe(ElementsFoodscraft instance) {
		super(instance, 128);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(ItemRawHumbug.block, (int) (1)), new ItemStack(ItemHumbug.block, (int) (1)), 1F);
	}
}
