
package net.mcreator.foods_craft.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;
import net.minecraft.init.Items;

import net.mcreator.foods_craft.item.ItemDriedbread;
import net.mcreator.foods_craft.ElementsFoodscraft;

@ElementsFoodscraft.ModElement.Tag
public class RecipeDriedbreadrecipe extends ElementsFoodscraft.ModElement {
	public RecipeDriedbreadrecipe(ElementsFoodscraft instance) {
		super(instance, 48);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(Items.BREAD, (int) (1)), new ItemStack(ItemDriedbread.block, (int) (1)), 0.1F);
	}
}
