
package net.mcreator.foods_craft.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.foods_craft.item.ItemCoockedBeacon;
import net.mcreator.foods_craft.item.ItemBeacon;
import net.mcreator.foods_craft.ElementsFoodscraft;

@ElementsFoodscraft.ModElement.Tag
public class RecipeBeaconRecipe extends ElementsFoodscraft.ModElement {
	public RecipeBeaconRecipe(ElementsFoodscraft instance) {
		super(instance, 121);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(ItemBeacon.block, (int) (1)), new ItemStack(ItemCoockedBeacon.block, (int) (1)), 1F);
	}
}
