
package net.mcreator.foods_craft.item.crafting;

import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

import net.minecraft.item.ItemStack;

import net.mcreator.foods_craft.item.ItemRawChorusFruitIngot;
import net.mcreator.foods_craft.item.ItemChorusFruitIngot;
import net.mcreator.foods_craft.ElementsFoodscraft;

@ElementsFoodscraft.ModElement.Tag
public class RecipeChorusFruitIngotSmelt extends ElementsFoodscraft.ModElement {
	public RecipeChorusFruitIngotSmelt(ElementsFoodscraft instance) {
		super(instance, 104);
	}

	@Override
	public void init(FMLInitializationEvent event) {
		GameRegistry.addSmelting(new ItemStack(ItemRawChorusFruitIngot.block, (int) (1)), new ItemStack(ItemChorusFruitIngot.block, (int) (1)), 0.1F);
	}
}
