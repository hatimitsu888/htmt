
package net.mcreator.foods_craft.creativetab;

import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraftforge.fml.relauncher.Side;

import net.minecraft.item.ItemStack;
import net.minecraft.creativetab.CreativeTabs;

import net.mcreator.foods_craft.item.ItemApplesword;
import net.mcreator.foods_craft.ElementsFoodscraft;

@ElementsFoodscraft.ModElement.Tag
public class TabFoodscraft extends ElementsFoodscraft.ModElement {
	public TabFoodscraft(ElementsFoodscraft instance) {
		super(instance, 28);
	}

	@Override
	public void initElements() {
		tab = new CreativeTabs("tabfoodscraft") {
			@SideOnly(Side.CLIENT)
			@Override
			public ItemStack getTabIconItem() {
				return new ItemStack(ItemApplesword.block, (int) (1));
			}

			@SideOnly(Side.CLIENT)
			public boolean hasSearchBar() {
				return false;
			}
		};
	}
	public static CreativeTabs tab;
}
