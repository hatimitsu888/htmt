package net.mcreator.foods_craft.procedure;

import net.minecraft.item.ItemStack;

import net.mcreator.foods_craft.ElementsFoodscraft;

import java.util.Random;

@ElementsFoodscraft.ModElement.Tag
public class ProcedureAppleswordMobIsHitWithItem extends ElementsFoodscraft.ModElement {
	public ProcedureAppleswordMobIsHitWithItem(ElementsFoodscraft instance) {
		super(instance, 29);
	}

	public static void executeProcedure(java.util.HashMap<String, Object> dependencies) {
		if (dependencies.get("itemstack") == null) {
			System.err.println("Failed to load dependency itemstack for procedure AppleswordMobIsHitWithItem!");
			return;
		}
		ItemStack itemstack = (ItemStack) dependencies.get("itemstack");
		if (itemstack.attemptDamageItem((int) 1, new Random(), null)) {
			itemstack.shrink(1);
			itemstack.setItemDamage(0);
		}
	}
}
